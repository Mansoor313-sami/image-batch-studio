// Runs on the Image Batch Studio website and relays its requests to the helper.
(() => {
  if (globalThis.imageBatchStudioHelper || !document.querySelector('meta[name="ibs-studio"]')) return;
  globalThis.imageBatchStudioHelper = true;
  const post = data => window.postMessage({ channel: 'ibs-helper', dir: 'from-helper', ...data }, location.origin);
  window.addEventListener('message', event => {
    const message = event.data;
    if (event.source !== window || event.origin !== location.origin) return;
    if (message?.channel !== 'ibs-helper' || message.dir !== 'to-helper' || typeof message.type !== 'string') return;
    chrome.runtime.sendMessage({ to: 'helper', type: message.type, payload: message.payload }).then(
      reply => post({ id: message.id, ...(reply || { ok: false, code: 'helper', error: 'The helper did not answer.' }) }),
      () => post({ id: message.id, ok: false, code: 'helper', error: 'The helper extension was reloaded. Refresh this page.' })
    );
  });
  post({ type: 'ready', version: chrome.runtime.getManifest().version });
})();
