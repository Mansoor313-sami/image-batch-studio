import { FLOW, FLOW_ORIGIN, StudioError, flowProject } from './model.js';

export async function openFlow(projectUrl) {
  const url = projectUrl || FLOW;
  const tabs = await chrome.tabs.query({ url: FLOW_ORIGIN + '/*' });
  const existing = tabs.find(tab => projectUrl ? flowProject(tab.url) === projectUrl : tab.active) ||
    (!projectUrl && tabs.find(tab => flowProject(tab.url)));
  if (!existing) return (await chrome.tabs.create({ url })).id;
  await chrome.tabs.update(existing.id, { active: true });
  await chrome.windows.update(existing.windowId, { focused: true });
  return existing.id;
}

export async function chooseProject(windowId) {
  const tabs = (await chrome.tabs.query({ url: FLOW_ORIGIN + '/project/*' })).filter(tab => flowProject(tab.url));
  const tab = tabs.find(tab => tab.active && tab.windowId === windowId) ||
    tabs.find(tab => tab.active && tabs.filter(other => other.active).length === 1) ||
    (tabs.length === 1 ? tabs[0] : null);
  if (!tab) throw new StudioError('tab', tabs.length
    ? 'Select the Flow project tab you want to use, then start the batch.'
    : 'Open Google Flow, sign in, and open a project before starting a batch.');
  return { url: flowProject(tab.url), tabId: tab.id };
}

export async function attach(flow) {
  const original = await chrome.tabs.get(flow.tabId).catch(() => null);
  let tab = original && flowProject(original.url) === flow.url ? original : null;
  if (!tab) {
    const matches = (await chrome.tabs.query({ url: FLOW_ORIGIN + '/project/*' })).filter(item => flowProject(item.url) === flow.url);
    if (matches.length === 1) tab = matches[0];
  }
  if (!tab) throw new StudioError('tab', 'Open the saved Flow project before resuming this batch.');
  try {
    const [{ documentId }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/flow.js'] });
    return { tabId: tab.id, documentId, url: flow.url };
  } catch {
    throw new StudioError('tab', 'The browser could not connect to the Flow project. Check the extension’s site access and try again.');
  }
}

export async function askFlow(document, type, data = {}) {
  let reply;
  try {
    reply = await chrome.tabs.sendMessage(document.tabId, { to: 'flow', type, url: document.url, ...data },
      { documentId: document.documentId });
  } catch {
    throw new StudioError('tab', 'The Flow project closed or reloaded.');
  }
  if (!reply?.ok) throw new StudioError(reply?.code || 'interface', reply?.error || 'The Flow project did not respond.');
  return reply.value;
}
