// Image Batch Studio Helper: lets the Image Batch Studio website generate images in a Google Flow tab.
import { StudioError, downloadFormat, flowImageUrl, flowProject, validAsset } from './model.js';
import { askFlow, attach, chooseProject, openFlow } from './browser.js';

const JOB_TIMEOUT = 240_000;
const DOWNLOAD_TIMEOUT = 25_000;
const memory = new Map();
let job = null;
let chain = Promise.resolve();

function serial(operation) {
  const task = chain.then(operation);
  chain = task.catch(() => {});
  return task;
}

async function flowTab() {
  try { return { url: (await chooseProject()).url }; }
  catch { return null; }
}

async function previewImage(src) {
  if (!flowImageUrl(src)) throw new StudioError('download', 'Flow did not provide an image address.');
  const response = await fetch(src, { credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new StudioError('download', 'Flow did not return the finished image.');
  const blob = await response.blob();
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let text = '';
  for (let index = 0; index < bytes.length; index += 0x8000) text += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  return { type: blob.type || 'image/jpeg', base64: btoa(text) };
}

function settle(current, error, value) {
  if (job !== current || current.settled) return;
  current.settled = true;
  clearTimeout(current.downloadTimer);
  if (error) current.reject(error);
  else current.resolve(value);
}

async function finish(current, image, original) {
  memory.set(current.flow.url, { references: current.references, lastAsset: current.asset.id });
  settle(current, null, { ...image, original });
}

async function usePreview(current) {
  try { await finish(current, await previewImage(current.asset.src), false); }
  catch (error) { settle(current, error); }
}

async function watch(current) {
  if (job !== current || current.settled) return;
  if (Date.now() - current.startedAt > JOB_TIMEOUT) {
    settle(current, new StudioError('timeout', 'Flow took too long to finish this scene.'));
    return;
  }
  if (current.phase === 'downloading') return;
  try {
    const state = await askFlow(current.doc, 'status');
    if (state?.attempt !== current.attempt) throw new StudioError('interrupted', 'Flow lost the current scene. Check the Flow tab.');
  } catch (error) { settle(current, error); }
}

async function generate({ text, model, ratio, save, folder, filename }) {
  if (job) throw new StudioError('busy', 'The helper is already generating a Flow image.');
  if (typeof text !== 'string' || !text.trim()) throw new StudioError('prompt', 'The scene has no prompt.');
  const flow = await chooseProject();
  const doc = await attach(flow);
  await askFlow(doc, 'check');
  const remembered = memory.get(flow.url) || {};
  const current = {
    attempt: crypto.randomUUID(), flow, doc, text, phase: 'preparing', startedAt: Date.now(),
    save: Boolean(save), folder: String(folder || 'Image Batch Studio'), filename: String(filename || 'Image')
  };
  const done = new Promise((resolve, reject) => Object.assign(current, { resolve, reject }));
  job = current;
  const timer = setInterval(() => void watch(current), 3000);
  try {
    await askFlow(doc, 'start', { attempt: current.attempt, text, options: {
      model, ratio, references: remembered.references, lastAsset: remembered.lastAsset
    } });
    return await done;
  } finally {
    clearInterval(timer);
    clearTimeout(current.downloadTimer);
    if (job === current) job = null;
  }
}

async function handleFlow(message, sender) {
  const current = job;
  if (!current || current.settled || message.attempt !== current.attempt || sender.tab?.id !== current.doc.tabId ||
      sender.documentId !== current.doc.documentId || flowProject(sender.url) !== current.flow.url) {
    throw new StudioError('interrupted', 'This Flow response no longer belongs to the current scene.');
  }
  if (message.type === 'flow:submitting' && current.phase === 'preparing') {
    if (!Array.isArray(message.references) || !message.references.every(validAsset)) {
      throw new StudioError('references', 'Flow did not confirm the reference image IDs.');
    }
    current.references = message.references;
    current.phase = 'generating';
    return;
  }
  if (message.type === 'flow:result' && current.phase === 'generating') {
    if (!validAsset(message.asset?.id)) throw new StudioError('match', 'Flow did not provide a valid image reference.');
    current.asset = { id: message.asset.id, src: message.asset.src };
    current.phase = 'downloading';
    current.downloadTimer = setTimeout(() => { if (!current.captured) void usePreview(current); }, DOWNLOAD_TIMEOUT);
    askFlow(current.doc, 'download', { id: current.asset.id }).catch(() => {
      if (!current.captured) void usePreview(current);
    });
    return;
  }
  if (message.type === 'flow:error') {
    settle(current, new StudioError(message.code || 'generation', String(message.error || 'Flow could not finish this scene.').slice(0, 400)));
    return;
  }
  throw new StudioError('request', 'Unexpected response from Flow.');
}

async function capture(current, item, format) {
  try {
    const blobUrl = item.finalUrl?.startsWith('blob:') ? item.finalUrl : item.url;
    if (!blobUrl?.startsWith('blob:')) throw new Error('not a blob');
    const image = await askFlow(current.doc, 'fetch-blob', { blobUrl });
    if (!image?.base64) throw new Error('empty');
    await finish(current, { type: image.type || `image/${format === 'jpg' ? 'jpeg' : format}`, base64: image.base64 }, true);
  } catch {
    await usePreview(current);
  }
}

async function handleSite(message) {
  const payload = message.payload || {};
  if (message.type === 'hello') return { version: chrome.runtime.getManifest().version, flow: await flowTab(), busy: Boolean(job) };
  if (message.type === 'open-flow') { await openFlow(); return null; }
  if (message.type === 'generate') return serial(() => generate(payload));
  throw new StudioError('request', 'Unknown helper action.');
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || typeof message?.type !== 'string') return;
  let task;
  if (message.to === 'helper' && sender.tab) task = handleSite(message);
  else if (message.to === 'worker' && message.type.startsWith('flow:') && sender.frameId === 0 && sender.documentId && flowProject(sender.url)) {
    task = handleFlow(message, sender);
  }
  if (!task) return;
  task.then(value => respond({ ok: true, value }), error => respond({ ok: false, code: error.code || 'helper', error: error.message }));
  return true;
});

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const current = job;
  const format = current?.phase === 'downloading' && !current.captured && downloadFormat(item, current.asset.id, current.flow.url);
  if (!format) return;
  current.captured = true;
  if (current.save) suggest({ filename: `${current.folder}/${current.filename}.${format}`, conflictAction: 'uniquify' });
  else suggest();
  void capture(current, item, format).finally(() => {
    if (!current.save) chrome.downloads.cancel(item.id).catch(() => {}).finally(() => chrome.downloads.erase({ id: item.id }).catch(() => {}));
  });
  return true;
});
