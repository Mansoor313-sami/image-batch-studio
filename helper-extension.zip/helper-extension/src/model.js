export const FLOW = 'https://flow.google.com/';
export const FLOW_ORIGIN = new URL(FLOW).origin;
export const MEDIA_ORIGIN = 'https://flow-content.google';
export const MODELS = ['Nano Banana 2.1', 'Nano Banana 2 Lite', 'Nano Banana Pro'];
export const ENGINES = [
  ['flow', 'Google Flow (free with your Google account)'],
  ['gemini', 'Gemini API (your API key)'],
  ['pollinations', 'Pollinations (free)']
];
export const ENGINE_NAMES = { flow: 'Google Flow', gemini: 'Gemini API', pollinations: 'Pollinations' };
export const GEMINI_MODELS = ['gemini-3.1-flash-image-preview', 'gemini-3.1-flash-lite-image', 'gemini-2.5-flash-image', 'gemini-3-pro-image-preview'];
export const POLLINATIONS_MODELS = ['flux', 'zimage', 'klein', 'gptimage', 'turbo'];
export const RATIO_SIZES = { '16:9': [1920, 1080], '9:16': [1080, 1920], '1:1': [1024, 1024], '4:3': [1440, 1080], '3:4': [1080, 1440] };
export const RATIOS = ['16:9', '9:16', '1:1', '4:3', '3:4'];
export const DEFAULT_FOLDER = 'Image Batch Studio';
export const JOB_STATES = ['pending', 'preparing', 'generating', 'downloading', 'completed', 'failed', 'skipped'];
export const ACTIVE = new Set(['running', 'pausing', 'stopping']);

export class StudioError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

export function flowProject(value) {
  try {
    const url = new URL(value);
    const project = /^\/project\/[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}\/?$/i;
    return url.origin === FLOW_ORIGIN && project.test(url.pathname) ? url.origin + url.pathname.replace(/\/$/, '') : null;
  } catch {
    return null;
  }
}

export const validAsset = value => typeof value === 'string' && /^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/i.test(value);

export function flowImageUrl(value) {
  try {
    const url = new URL(value);
    return url.origin === MEDIA_ORIGIN && url.pathname.startsWith('/image/') ? url.href : null;
  } catch {
    return null;
  }
}

export function initialDraft() {
  return {
    text: '', name: '', model: MODELS[0], ratio: RATIOS[0], prefix: 'Image', folder: DEFAULT_FOLDER,
    engine: 'flow', geminiModel: GEMINI_MODELS[0], pollinationsModel: POLLINATIONS_MODELS[0], workers: 3,
    startFrom: '', fallback: true, save: true,
    characterOn: false, character: '', styleOn: false, style: ''
  };
}

export const engineOf = settings => settings?.engine || 'flow';

export function engineModel(settings, engine = engineOf(settings)) {
  if (engine === 'gemini') return settings.geminiModel;
  if (engine === 'pollinations') return settings.pollinationsModel;
  return settings.model;
}

export function composePrompt(text, { characterOn, character, styleOn, style } = {}) {
  const sentence = value => {
    const clean = String(value ?? '').replace(/\s+/g, ' ').trim();
    return clean && !/[.!?]$/.test(clean) ? clean + '.' : clean;
  };
  const parts = [String(text ?? '').trim()];
  if (characterOn && sentence(character)) parts.push('Character (keep consistent): ' + sentence(character));
  if (styleOn && sentence(style)) parts.push('Style: ' + sentence(style));
  return parts.filter(Boolean).join(parts[0].includes('\n') ? '\n' : ' ');
}

export function parsePrompts(input) {
  const text = input.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const lines = text.split('\n');
  const visible = lines.filter(line => line.trim());
  if (!visible.length) return [];
  const heading = /^\s*(?:Image|Scene|Prompt)\s+(\d+)(?:\s+Prompt)?\s*[:.)-]\s?(.*)$/i;
  const numbered = /^\s*(\d+)[.)]\s+(.*)$/;
  const prompts = [];
  if (heading.test(visible[0])) {
    let job;
    for (const line of lines) {
      const match = line.match(heading);
      if (match) {
        job = { number: Number(match[1]), text: match[2] };
        prompts.push(job);
      } else if (job) job.text += (job.text ? '\n' : '') + line;
    }
  } else if (visible.every(line => numbered.test(line))) {
    for (const line of visible) {
      const [, number, content] = line.match(numbered);
      prompts.push({ number: Number(number), text: content });
    }
  } else {
    for (const [index, line] of visible.entries()) prompts.push({ number: index + 1, text: line });
  }
  const numbers = new Set();
  for (const job of prompts) {
    job.text = job.text.trim();
    if (!Number.isSafeInteger(job.number) || job.number < 1 || !job.text) {
      throw new StudioError('prompts', 'Every numbered scene needs a positive number and a prompt.');
    }
    if (numbers.has(job.number)) throw new StudioError('prompts', `Image ${job.number} appears twice. Give each scene a unique number.`);
    numbers.add(job.number);
  }
  return prompts.sort((first, second) => first.number - second.number);
}

export function safeSegment(value, fallback, length = 60) {
  let text = String(value ?? '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim().replace(/[. ]+$/g, '');
  let shortened = '';
  for (const character of text) {
    if (shortened.length + character.length > length) break;
    shortened += character;
  }
  text = shortened.replace(/[. ]+$/g, '') || fallback;
  if (/^(?:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])(?:\s*\.|$)/i.test(text)) return '_' + text;
  return text;
}

export function folderRoot(value) {
  const text = String(value ?? '').trim();
  if (!text) return DEFAULT_FOLDER;
  if (/^(?:[\\/]|[a-z]:)/i.test(text) || text.split(/[\\/]/).some(part => /^\.{1,2}$/.test(part.trim()))) {
    throw new StudioError('output', 'Enter a folder inside the browser’s Downloads folder.');
  }
  return text.split(/[\\/]/).filter(part => part.trim()).map(part => safeSegment(part, '_')).join('/') || DEFAULT_FOLDER;
}

export function validateDraft(draft) {
  const prompts = parsePrompts(draft.text);
  if (!prompts.length) throw new StudioError('prompts', 'Add at least one image prompt.');
  const name = String(draft.name ?? '').trim();
  if (!name) throw new StudioError('output', 'Enter a project name in Settings.');
  const engine = draft.engine || 'flow';
  if (!ENGINE_NAMES[engine]) throw new StudioError('settings', 'Choose an image engine.');
  if ((engine === 'flow' && !MODELS.includes(draft.model)) || !RATIOS.includes(draft.ratio)) {
    throw new StudioError('settings', 'Choose a Google Flow image model and aspect ratio.');
  }
  const geminiModel = String(draft.geminiModel || GEMINI_MODELS[0]).trim();
  const pollinationsModel = String(draft.pollinationsModel || POLLINATIONS_MODELS[0]).trim();
  if (!/^[\w.-]+$/.test(geminiModel) || !/^[\w.-]+$/.test(pollinationsModel)) {
    throw new StudioError('settings', 'Model names can only use letters, numbers, dots and dashes.');
  }
  const digits = Math.max(3, String(prompts.at(-1).number).length);
  let startFrom = 1;
  if (String(draft.startFrom ?? '').trim()) {
    startFrom = Number(draft.startFrom);
    if (!Number.isSafeInteger(startFrom) || startFrom < 1) throw new StudioError('settings', 'Start from must be a positive scene number.');
  }
  const remaining = prompts.filter(prompt => prompt.number >= startFrom);
  if (!remaining.length) throw new StudioError('settings', `No scenes are numbered ${startFrom} or higher.`);
  const consistency = {
    characterOn: Boolean(draft.characterOn), character: String(draft.character ?? '').trim(),
    styleOn: Boolean(draft.styleOn), style: String(draft.style ?? '').trim()
  };
  const workers = Math.min(5, Math.max(1, Math.round(Number(draft.workers) || 1)));
  return {
    prompts: remaining.map(({ number, text }) => ({ number, prompt: text, text: composePrompt(text, consistency) })),
    settings: {
      name, total: remaining.length, digits, startFrom,
      prefix: safeSegment(draft.prefix, 'Image'), root: folderRoot(draft.folder), model: draft.model, ratio: draft.ratio,
      engine, geminiModel, pollinationsModel, workers, fallback: draft.fallback !== false, save: draft.save !== false,
      ...consistency
    }
  };
}

export function sceneName(settings, number) {
  return `${settings.prefix} ${String(number).padStart(settings.digits, '0')}`;
}

export function downloadFormat(item, assetId, projectUrl) {
  if (item.byExtensionId || !validAsset(assetId)) return null;
  const base = item.filename.split(/[/\\]/).at(-1);
  const ending = new RegExp(`_${assetId.slice(0, 8)}\\.(jpg|jpeg|png|webp)$`, 'i');
  const match = base.match(ending);
  if (!match || (item.mime && !/^(?:image\/|application\/octet-stream)/i.test(item.mime))) return null;
  const referrer = flowProject(item.referrer);
  if (referrer && referrer !== projectUrl) return null;
  const flowSource = [item.url, item.finalUrl, item.referrer].some(value => {
    try { return [FLOW_ORIGIN, MEDIA_ORIGIN].includes(new URL(value).origin); }
    catch { return false; }
  });
  if (!flowSource) return null;
  return match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
}

export function matchesFile(actual, relative) {
  const normal = actual.replaceAll('\\', '/').toLowerCase();
  const wanted = relative.toLowerCase();
  if (normal.endsWith('/' + wanted)) return true;
  const suffix = normal.match(/ \(\d+\)(?=\.[a-z]+$)/);
  return Boolean(suffix && (normal.slice(0, suffix.index) + normal.slice(suffix.index + suffix[0].length)).endsWith('/' + wanted));
}

export function csv(rows) {
  return rows.map(row => row.map(cell => {
    const value = String(cell ?? '');
    const safe = /^\s*[=+@\-]/.test(value) ? "'" + value : value;
    return '"' + safe.replaceAll('"', '""') + '"';
  }).join(',')).join('\r\n') + '\r\n';
}

export function engineLabel(settings, engine = engineOf(settings)) {
  return `${ENGINE_NAMES[engine]} · ${engineModel(settings, engine)}`;
}

export function imageExtension(type) {
  return { 'image/png': 'png', 'image/webp': 'webp', 'image/jpeg': 'jpg' }[String(type).split(';')[0]] || 'jpg';
}

export const labelStatus = status => status ? status[0].toUpperCase() + status.slice(1) : '';
