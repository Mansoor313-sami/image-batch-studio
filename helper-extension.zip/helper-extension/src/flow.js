// Interact with the visible prompt box, project grid, and download menu in Flow.
(() => {
  if (globalThis.imageBatchStudio) return;
  globalThis.imageBatchStudio = true;
  const nodes = (root, selector) => [...(root?.querySelectorAll(selector) ?? [])];
  const shown = node => Boolean(node?.getClientRects().length && getComputedStyle(node).visibility !== 'hidden');
  const visible = (root, selector) => nodes(root, selector).filter(shown);
  const fault = (code, message) => Object.assign(new Error(message), { code });
  const normalize = text => String(text ?? '').replace(/\r\n?/g, '\n').trim();
  const controlName = node => {
    if (node.hasAttribute('aria-label')) return node.getAttribute('aria-label').trim();
    const label = node.cloneNode(true);
    for (const icon of nodes(label, 'mat-icon, svg, [aria-hidden="true"]')) icon.remove();
    return label.textContent.replace(/\s+/g, ' ').trim();
  };
  const find = (root, selector, name) => visible(root, selector).find(node => controlName(node) === name);
  const button = (root, name) => find(root, 'button', name);
  const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
  let active;

  function scope(url) {
    if (location.origin + location.pathname.replace(/\/$/, '') !== url) {
      throw fault('tab', 'Open the saved Flow project in its original tab and resume the batch.');
    }
  }

  function classify(text) {
    if (/too quickly|too many requests|rate limit|try again in \d|\b429\b/i.test(text)) return 'rate';
    if (/daily.{0,35}(?:limit|quota)|(?:limit|quota).{0,35}(?:reached|exceeded)|(?:out of|not enough|insufficient) credits/i.test(text)) return 'quota';
    if (/captcha|unusual activity|verify (?:that )?you(?: are|'re) human|security check/i.test(text)) return 'security';
    if (/sign in|log in|account verification/i.test(text)) return 'auth';
    if (/restricted|blocked|safety|policy/i.test(text)) return 'policy';
    return 'generation';
  }

  function restriction() {
    const challenge = visible(document, 'iframe[title]').find(node =>
      /recaptcha challenge|security check|verify you are human/i.test(node.title));
    if (challenge) throw fault('security', 'Flow is asking for a security check. Complete it in the Flow tab before resuming.');
    for (const alert of visible(document, '[role="alertdialog"], [role="alert"], mat-snack-bar-container')) {
      const text = normalize(alert.innerText);
      const code = classify(text);
      if (['rate', 'quota', 'security', 'auth'].includes(code)) throw fault(code, text.slice(0, 350));
    }
  }

  async function until(check, timeout, code, message) {
    const end = Date.now() + timeout;
    do {
      const value = check();
      if (value) return value;
      await wait(125);
    } while (Date.now() < end);
    throw fault(code, message);
  }

  function composer() {
    const root = visible(document, 'flow-prompt-box').find(node =>
      button(node, 'Settings trigger') || node.querySelector('button.agent-mode-chip'));
    const editor = root?.querySelector('flow-rich-text-editor [contenteditable="true"][role="textbox"]');
    const start = button(root, 'Start generation');
    return editor && start ? { root, editor, start } : null;
  }

  async function standardComposer() {
    if (!composer()) {
      const collapse = visible(document, 'button[aria-label="Close"]').find(close => {
        for (let node = close.parentElement; node && node !== document.body; node = node.parentElement) {
          if (button(node, 'Open session history') && button(node, 'Start new session')) return true;
          if (node.id === 'main-content') return false;
        }
        return false;
      });
      collapse?.click();
    }
    const ui = await until(composer, 8_000, 'interface',
      'Open a Flow project with its standard prompt box. Close the expanded Agent panel if it is open.');
    const agent = ui.root.querySelector('button.agent-mode-chip[aria-pressed="true"]');
    if (agent) agent.click();
    return until(() => {
      const normal = composer();
      return normal && button(normal.root, 'Settings trigger') &&
        normal.root.querySelector('button.agent-mode-chip[aria-pressed="false"]') && normal;
    }, 4000, 'settings', 'Turn off Agent in the Flow prompt box to use standard Image mode.');
  }

  async function chooseRadio(settings, name) {
    const choice = await until(() => find(settings(), '[role="radio"]', name), 3000, 'settings',
      `Flow does not offer ${name} in the current generation settings.`);
    if (choice.getAttribute('aria-checked') !== 'true') choice.click();
    await until(() => find(settings(), '[role="radio"]', name)?.getAttribute('aria-checked') === 'true',
      3000, 'settings', `Flow did not select ${name}.`);
  }

  async function applySettings(options) {
    await standardComposer();
    const settings = () => visible(document, 'flow-prompt-box-settings')[0];
    if (!settings()) button(composer().root, 'Settings trigger').click();
    await until(settings, 4000, 'interface', 'Flow’s generation settings could not open.');
    await chooseRadio(settings, 'Image');
    const select = button(settings(), 'Select model family');
    if (!select) throw fault('settings', 'Flow’s image model list could not be found.');
    if (!select.textContent.includes(options.model)) {
      select.click();
      const item = await until(() => visible(document, '[role="menuitem"]')
        .find(node => controlName(node).replace(/^🍌\s*/u, '') === options.model),
      4000, 'settings', `Flow does not offer ${options.model} on this account.`);
      item.click();
      await until(() => button(settings(), 'Select model family')?.textContent.includes(options.model),
        4000, 'settings', 'Flow did not confirm the selected image model.');
    }
    await chooseRadio(settings, options.ratio);
    await chooseRadio(settings, 'x1');
    const cost = settings().innerText.replace(/\s+/g, ' ');
    button(composer().root, 'Settings trigger').click();
    await until(() => !settings(), 4000, 'interface', 'Close Flow’s generation settings before starting.');
    if (!/Generating will use\s+0\s+credits?\b/i.test(cost)) {
      throw fault('credits', 'Flow did not confirm 0 credits for this image. Check the model and Image settings before resuming.');
    }
  }

  function promptText(editor) {
    const paragraphs = nodes(editor, ':scope > p');
    const value = paragraphs.length === editor.children.length && paragraphs.length
      ? paragraphs.map(node => node.innerText.replace(/\n$/, '')).join('\n')
      : editor.innerText;
    return normalize(value);
  }

  async function fill(text) {
    const ui = composer();
    if (!ui) throw fault('interface', 'Flow’s standard prompt editor is unavailable.');
    ui.editor.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(ui.editor);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('insertText', false, text);
    return until(() => {
      const updated = composer();
      return updated && !updated.start.disabled && promptText(updated.editor) === text && updated;
    }, 3500, 'prompt', 'Flow did not accept the complete prompt. Review the text in the Flow tab.');
  }

  const grids = () => visible(document, 'flow-grid-tile-container');
  const images = () => grids().map(tile => tile.querySelector('flow-image-tile img[data-media-id]')).filter(Boolean);
  const assetOf = image => image.getAttribute('data-media-id');
  const loaded = image => image.complete && image.naturalWidth > 0;
  const reuseButton = image => image?.closest('flow-image-tile')?.querySelector('button[aria-label="Reuse prompt"]');

  async function newestResults() {
    button(document, 'All media')?.click();
    const trigger = button(document, 'Filtering and sorting options');
    if (trigger) {
      const panel = () => visible(document, '[role="dialog"][aria-label="Filtering and sorting options"]')[0];
      if (!panel()) trigger.click();
      await until(panel, 3000, 'interface', 'Flow’s result filters did not open.');
      const clear = button(panel(), 'Clear all filters');
      if (clear && !clear.disabled) clear.click();
      const newest = () => nodes(panel(), 'input[type="radio"]').find(input =>
        [...(input.labels ?? [])].some(label => label.textContent.trim() === 'Newest'));
      const option = await until(newest, 3000, 'interface', 'Set the Flow project’s result order to Newest.');
      if (!option.checked) option.click();
      await until(() => newest()?.checked, 3000, 'interface', 'Flow did not confirm its Newest result order.');
      if (panel()) trigger.click();
      await until(() => !panel(), 3000, 'interface', 'Close the Flow result filters before continuing.');
    }
    for (const view of visible(document, 'cdk-virtual-scroll-viewport')) view.scrollTop = 0;
  }

  function references(root) {
    return nodes(root, 'flow-ingredient-chip').map(chip => {
      const src = chip.querySelector('flow-image-ingredient-chip img')?.src;
      const id = src && new URL(src).pathname.match(/^\/image\/([a-f0-9-]{36})$/i)?.[1];
      if (!id) throw fault('references', 'Wait for Flow to finish loading the reference image before resuming.');
      return id;
    });
  }

  const sameReferences = (first, second) => first.length === second.length && first.every((id, index) => id === second[index]);

  async function prepareReferences(options) {
    const ui = composer();
    const attached = references(ui.root);
    const expected = options.references;
    if (!expected || sameReferences(expected, attached)) return attached;
    const previous = reuseButton(images().find(image => assetOf(image) === options.lastAsset));
    if (!attached.length && previous && !promptText(ui.editor)) {
      previous.click();
      return until(() => {
        const current = composer();
        if (current && sameReferences(expected, references(current.root))) return expected;
      }, 4500, 'references', 'Attach the original reference images in Flow, then select Resume.');
    }
    throw fault('references', 'Match the reference images to the ones used at the start of this batch, then select Resume.');
  }

  async function send(type, data) {
    const reply = await chrome.runtime.sendMessage({ to: 'worker', type, ...data });
    if (!reply?.ok) throw fault(reply?.code || 'interrupted', reply?.error || 'The batch queue lost contact with Flow.');
    return reply.value;
  }

  function newResult(snapshot, text) {
    restriction();
    const fresh = images().filter(image => !snapshot.images.has(assetOf(image)));
    if (fresh.length > 1) throw fault('match', 'Flow returned several new images. Review the project before retrying this scene.');
    if (fresh.length === 1 && loaded(fresh[0])) return fresh[0];
    const entry = grids().find(tile => !snapshot.tiles.has(tile) && !tile.querySelector('img[data-media-id]') &&
      /failed|could(?:n['’]t| not) generate|something went wrong|daily limit|quota|too quickly|unusual activity/i.test(tile.innerText) &&
      !/\d+%/.test(tile.innerText));
    if (entry) {
      const message = normalize(entry.innerText).replace(text, '').trim() || 'Flow could not generate this scene.';
      throw fault(classify(message), message.slice(0, 350));
    }
    return null;
  }

  async function generation({ url, options, text, attempt }) {
    try {
      scope(url);
      restriction();
      await newestResults();
      if (grids().some(tile => !tile.querySelector('img[data-media-id]') && /^\d+%\s/.test(normalize(tile.innerText)))) {
        throw fault('busy', 'Wait for the current Flow generation to finish before starting the queue.');
      }
      await applySettings(options);
      const attached = await prepareReferences(options);
      const ui = await fill(text);
      const snapshot = { images: new Set(images().map(assetOf)), tiles: new Set(grids()) };
      await send('flow:submitting', { attempt, references: attached });
      scope(url);
      restriction();
      const summary = button(ui.root, 'Settings trigger')?.textContent ?? '';
      if (!ui.start.isConnected || ui.start.disabled || promptText(ui.editor) !== text ||
          !summary.includes(options.model) || !/\bx1\b/i.test(summary) ||
          !sameReferences(attached, references(ui.root)) ||
          !ui.root.querySelector('button.agent-mode-chip[aria-pressed="false"]')) {
        throw fault('prompt', 'The Flow prompt or settings changed before submission. Review the Flow tab.');
      }
      ui.start.click();
      const image = await until(() => { scope(url); return newResult(snapshot, text); }, 180_000, 'timeout',
        'No matching image appeared. Check Flow’s All media view and the latest result before retrying.');
      const reuse = reuseButton(image);
      if (!reuse || !composer() || promptText(composer().editor)) {
        throw fault('match', 'The Flow prompt box changed before the image could be matched.');
      }
      reuse.click();
      const recovered = await until(() => {
        const editor = composer()?.editor;
        return editor && promptText(editor);
      }, 4500, 'match', 'Flow did not expose the original prompt for this image.');
      if (recovered !== text) throw fault('match', 'The image’s original Flow prompt did not match this scene.');
      await send('flow:result', {
        attempt, asset: { id: assetOf(image), src: image.currentSrc || image.src }
      });
      active.status = 'ready';
    } catch (error) {
      active.status = 'failed';
      await send('flow:error', { attempt, code: error.code || 'interface', error: error.message }).catch(() => {});
    }
  }

  async function download({ url, id }) {
    scope(url);
    restriction();
    const image = images().find(node => assetOf(node) === id);
    const more = image?.closest('flow-image-tile')?.querySelector('button[aria-label="More options"]');
    if (!more) throw fault('download', 'Open All media in the Flow project and locate the generated image before retrying its download.');
    more.click();
    const menu = await until(() => find(document, '[role="menuitem"]', 'Download'), 3500,
      'download', 'Flow’s Download menu did not open.');
    menu.click();
    const original = await until(() => visible(document, '[role="menuitem"]').find(node =>
      /^(?:[124]K )?Original(?: size)?$/i.test(controlName(node)) && !node.disabled),
    3500, 'download', 'Flow did not offer an original-size download.');
    scope(url);
    restriction();
    original.click();
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.tab || message?.to !== 'flow') return;
    const { type, attempt, url } = message;
    if (type === 'status') { respond({ ok: true, value: active }); return; }
    if (type === 'start') {
      if (active?.attempt === attempt) { respond({ ok: true }); return; }
      if (active?.status === 'working') {
        respond({ ok: false, code: 'busy', error: 'A previous scene is still running in Flow.' });
        return;
      }
      active = { attempt, status: 'working' };
      respond({ ok: true });
      void generation(message);
      return;
    }
    let task;
    if (type === 'fetch-blob') task = (async () => {
      if (typeof message.blobUrl !== 'string' || !message.blobUrl.startsWith('blob:' + location.origin + '/')) {
        throw fault('download', 'Unexpected download address.');
      }
      const blob = await (await fetch(message.blobUrl)).blob();
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });
      return { type: blob.type, base64: String(dataUrl).split(',')[1] || '' };
    })();
    if (type === 'check') task = Promise.resolve().then(() => { scope(url); restriction(); });
    if (type === 'download') task = download(message);
    if (!task) return;
    task.then(value => respond({ ok: true, value }), error =>
      respond({ ok: false, code: error.code || 'interface', error: error.message }));
    return true;
  });
})();
